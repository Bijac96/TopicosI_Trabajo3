﻿using System;

namespace ControlAcceso.Modelos
{
    public class UsuarioLugar
    {
        public int usuId { get; set; }

        public int place_id { get; set; }
    }

}
