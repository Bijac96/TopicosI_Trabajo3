﻿using System;

namespace ControlAcceso.Modelos
{
    public class UsuarioLugar
    {
        public int user_id { get; set; }
        public Usuario user { get; set; }

        public int place_id { get; set; }
        public Lugar place { get; set; }
    }

}
