﻿namespace ControlAcceso.Modelos
{
    public class Categoria
    {
        public int catId {  get; set; }
        public string? cat_name { get; set; }
    }
}
