﻿using System;
using System.Text.Json.Serialization;

namespace ControlAcceso.Modelos
{
    public class Usuario
    {
        public string? usuId { get; set; }
        public string usuNombre { get; set; }
        public string user_rut { get; set; }
        public string? user_phone { get; set; }
        public string? user_email { get; set; }

        public Categoria user_category { get; set; }
        public Facultad user_faculty { get; set; }
        public string? user_university { get; set; }
        public Rol user_role { get; set; }
        [JsonIgnore]
        public DateTime creation_date { get; set; }
        public string? creator_user_id { get; set; }
        public DateTime? start_date { get; set; }
        public DateTime? end_date { get; set; }
        public string user_status { get; set; }
        //public ICollection<UsuarioLugar> UsuarioLugares { get; set; }
    }
}
