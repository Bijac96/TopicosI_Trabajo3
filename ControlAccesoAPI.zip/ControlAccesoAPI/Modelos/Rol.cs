﻿using System;

namespace ControlAcceso.Modelos
{
    public class Rol
    {
        public int rol_id { get; set; }
        public string? rol_name { get; set; } 
    }
}
