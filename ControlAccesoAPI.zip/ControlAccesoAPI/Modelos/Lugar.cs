﻿using System;
using System.Text.Json.Serialization;

namespace ControlAcceso.Modelos
{
    public class Lugar
    {
        public int place_id { get; set; }
        public string? place_name { get; set; }
        [JsonIgnore]
        public ICollection<UsuarioLugar>? UsuarioLugares { get; set; }
    }
}
