﻿using System;

namespace ControlAcceso.Modelos
{
    public class Lugar
    {
        public int place_id { get; set; }
        public string? place_name { get; set; }
        //public ICollection<UsuarioLugar> UsuarioLugares { get; set; }
    }
}
