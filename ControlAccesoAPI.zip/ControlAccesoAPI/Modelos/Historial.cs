﻿namespace ControlAcceso.Modelos
{
    public class Historial
    {
        public int id {  get; set; }
        public DateTime? fecha { get; set; }
        public string? controlador { get; set; }
        public string? observacion { get; set; }
        public string? elemento { get; set; }
    }
}
