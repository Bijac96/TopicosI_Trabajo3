﻿using ControlAcceso.Modelos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.Json.Serialization;

namespace ControlAcceso.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RolController : ControllerBase 
    {
        private readonly string _conexionSQL;
        public RolController(IConfiguration config)
        {
            _conexionSQL = config.GetConnectionString("ConexionBDSQL");
        }

        [HttpPost]
        [Route("Crear")]
        public IActionResult Crear([FromBody] Rol nuevoRol)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Rol", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@rol_id", nuevoRol.rol_id);
                    cmd.Parameters.AddWithValue("@rol_name", nuevoRol.rol_name);
                    cmd.Parameters.AddWithValue("@modo", "C");

                    cmd.ExecuteNonQuery();
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpGet]
        [Route("Lista")]
        public IActionResult Lista()
        {
            List<Rol> lRoles = new List<Rol>();
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Rol", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@modo", "L");

                    using (SqlDataReader resultadoSP = cmd.ExecuteReader())
                    {
                        while (resultadoSP.Read())
                        {
                            lRoles.Add(new Rol()
                            {
                                rol_id = resultadoSP.GetInt32(0),
                                rol_name = resultadoSP[1].ToString(),
                            }); ;
                        }
                    }
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", lRoles = lRoles });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message, lRoles = lRoles });
            }
        }

        [HttpGet]
        [Route("Obtener")]
        public IActionResult Obtener(int rol_id)
        {
            Rol rol_info = new Rol();
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Rol", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@rol_id", rol_id);
                    cmd.Parameters.AddWithValue("@modo", "G");
                    using (SqlDataReader resultadoSP = cmd.ExecuteReader())
                    {
                        while (resultadoSP.Read())
                        {
                            rol_info = new Rol()
                            {
                                rol_id = resultadoSP.GetInt32(0),
                                rol_name = resultadoSP[1].ToString(),
                            };
                        }
                    }
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", rol = rol_info });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message, rol = rol_info });
            }
        }


        [HttpPut]
        [Route("Modificar")]
        public IActionResult Modificar([FromBody] Rol rol)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Rol", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@rol_id", rol.rol_id);
                    cmd.Parameters.AddWithValue("@rol_name", rol.rol_name);
                    
                    cmd.Parameters.AddWithValue("@modo", "M");
                    cmd.ExecuteNonQuery();
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpDelete]
        [Route("Eliminar")]
        public IActionResult Eliminar(int rol_id)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Rol", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@rol_id", rol_id);
                    cmd.Parameters.AddWithValue("@modo", "D");
                    cmd.ExecuteNonQuery();
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }
    }
}