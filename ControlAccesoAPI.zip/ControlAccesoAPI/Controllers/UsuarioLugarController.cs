﻿using ControlAcceso.Modelos;
using static ControlAcceso.Funciones.Funciones;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text.Json.Serialization;
using ControlAcceso.Funciones;

namespace ControlAcceso.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioLugarController : ControllerBase
    {
        private readonly string _conexionSQL;
        private readonly IHistorialServicios _historialServicios;
        public UsuarioLugarController(IConfiguration config, IHistorialServicios historialServicios)
        {
            _conexionSQL = config.GetConnectionString("ConexionBDSQL");
            _historialServicios = historialServicios;
        }

        [HttpPost]
        [Route("AsignarLugar")]
        public IActionResult AsignarLugar([FromBody] UsuarioLugar usuarioLugar)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_UsuarioLugar", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@usuId", usuarioLugar.usuId);
                    cmd.Parameters.AddWithValue("@place_id", usuarioLugar.place_id);
                    cmd.Parameters.AddWithValue("@modo", "C");

                    cmd.ExecuteNonQuery();
                }
                _historialServicios.RegistrarAccion(new Historial
                {
                    fecha = DateTime.Now,
                    controlador = "AsignarLugar",
                    observacion = "Se asigno un lugar a un usuario",
                    elemento = "Usuario: " + usuarioLugar.usuId.ToString() + ", Lugar: " + usuarioLugar.place_id.ToString()
                });
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }
    }
}