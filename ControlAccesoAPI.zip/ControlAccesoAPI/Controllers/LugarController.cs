﻿using ControlAcceso.Modelos;
using static ControlAcceso.Funciones.Funciones;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text.Json.Serialization;

namespace ControlAcceso.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LugarController : ControllerBase 
    {
        private readonly string _conexionSQL;
        public LugarController(IConfiguration config)
        {
            _conexionSQL = config.GetConnectionString("ConexionBDSQL");
        }

        [HttpPost]
        [Route("Crear")]
        public IActionResult Crear([FromBody] Lugar nuevoLugar)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Lugar", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@place_id", nuevoLugar.place_id);
                    cmd.Parameters.AddWithValue("@place_name", nuevoLugar.place_name);
                    cmd.Parameters.AddWithValue("@modo", "C");

                    cmd.ExecuteNonQuery();
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpGet]
        [Route("Lista")]
        public IActionResult Lista()
        {
            List<Lugar> lLugares = new List<Lugar>();
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Lugar", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@modo", "L");

                    using (SqlDataReader resultadoSP = cmd.ExecuteReader())
                    {
                        while (resultadoSP.Read())
                        {
                            lLugares.Add(new Lugar()
                            {
                                place_id = resultadoSP.GetInt32(0),
                                place_name = resultadoSP[1].ToString(),
                            });;
                        }
                    }
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", lLugares = lLugares });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message, lLugares = lLugares });
            }
        }

        [HttpGet]
        [Route("Obtener")]
        public IActionResult Obtener(int place_id)
        {
            Lugar place_info = new Lugar();
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Lugar", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@place_id", place_id);
                    cmd.Parameters.AddWithValue("@modo", "G");
                    using (SqlDataReader resultadoSP = cmd.ExecuteReader())
                    {
                        while (resultadoSP.Read())
                        {
                            place_info = new Lugar()
                            {
                                place_id = resultadoSP.GetInt32(0),
                                place_name = resultadoSP[1].ToString(),
                            };
                        }
                    }
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", place = place_info });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message, place = place_info });
            }
        }


        [HttpPut]
        [Route("Modificar")]
        public IActionResult Modificar([FromBody] Lugar place)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Lugar", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@place_id", place.place_id);
                    cmd.Parameters.AddWithValue("@place_name", place.place_name);

                    cmd.Parameters.AddWithValue("@modo", "M");
                    cmd.ExecuteNonQuery();
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpDelete]
        [Route("Eliminar")]
        public IActionResult Eliminar(int place_id)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Lugar", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@place_id", place_id);
                    cmd.Parameters.AddWithValue("@modo", "D");
                    cmd.ExecuteNonQuery();
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }
    }
}