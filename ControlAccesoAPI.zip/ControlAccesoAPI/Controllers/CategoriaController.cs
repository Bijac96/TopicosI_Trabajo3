﻿using ControlAcceso.Funciones;
using ControlAcceso.Modelos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.Json.Serialization;

namespace ControlAcceso.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriaController : ControllerBase 
    {
        private readonly string _conexionSQL;
        private readonly IHistorialServicios _historialServicios;
        public CategoriaController(IConfiguration config, IHistorialServicios historialServicios)
        {
            _conexionSQL = config.GetConnectionString("ConexionBDSQL");
            _historialServicios = historialServicios;
        }

        [HttpPost]
        [Route("Crear")]
        public IActionResult Crear([FromBody] Categoria nuevaCategoria)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Categoria", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@catId", nuevaCategoria.catId);
                    cmd.Parameters.AddWithValue("@cat_name", nuevaCategoria.cat_name);
                    cmd.Parameters.AddWithValue("@modo", "C");

                    cmd.ExecuteNonQuery();
                }
                _historialServicios.RegistrarAccion(new Historial
                {
                    fecha = DateTime.Now,
                    controlador = "Crear Categoria",
                    observacion = "Se creo una categoria",
                    elemento = "Categoria: " + nuevaCategoria.catId.ToString()
                });
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpGet]
        [Route("Lista")]
        public IActionResult Lista()
        {
            List<Categoria> lCategorias = new List<Categoria>();
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Categoria", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@modo", "L");

                    using (SqlDataReader resultadoSP = cmd.ExecuteReader())
                    {
                        while (resultadoSP.Read())
                        {
                            lCategorias.Add(new Categoria()
                            {
                                catId = resultadoSP.GetInt32(0),
                                cat_name = resultadoSP[1].ToString(),
                            }); ;
                        }
                    }
                }
                _historialServicios.RegistrarAccion(new Historial
                {
                    fecha = DateTime.Now,
                    controlador = "Lista Categoria",
                    observacion = "Se listaron las categorias",
                    elemento = "Categorias"
                });
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", lCategorias = lCategorias });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message, lCategorias = lCategorias });
            }
        }

        [HttpGet]
        [Route("Obtener")]
        public IActionResult Obtener(int catId)
        {
            Categoria cat_info = new Categoria();
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Categoria", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@catId", catId);
                    cmd.Parameters.AddWithValue("@modo", "G");
                    using (SqlDataReader resultadoSP = cmd.ExecuteReader())
                    {
                        while (resultadoSP.Read())
                        {
                            cat_info = new Categoria()
                            {
                                catId = resultadoSP.GetInt32(0),
                                cat_name = resultadoSP[1].ToString(),
                            };
                        }
                    }
                }
                _historialServicios.RegistrarAccion(new Historial
                {
                    fecha = DateTime.Now,
                    controlador = "Obtener Categoria",
                    observacion = "Se obtuvo una categoria",
                    elemento = "Categoria: " + catId.ToString()
                });
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", categoria = cat_info });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message, categoria = cat_info });
            }
        }


        [HttpPut]
        [Route("Modificar")]
        public IActionResult Modificar([FromBody] Categoria categoria)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Categoria", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@catId", categoria.catId);
                    cmd.Parameters.AddWithValue("@cat_name", categoria.cat_name);
                    
                    cmd.Parameters.AddWithValue("@modo", "M");
                    cmd.ExecuteNonQuery();
                }
                _historialServicios.RegistrarAccion(new Historial
                {
                    fecha = DateTime.Now,
                    controlador = "Modificar Categoria",
                    observacion = "Se modifico una categoria",
                    elemento = "Categoria: " + categoria.catId.ToString()
                });
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpDelete]
        [Route("Eliminar")]
        public IActionResult Eliminar(int catId)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Categoria", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@catId", catId);
                    cmd.Parameters.AddWithValue("@modo", "D");
                    cmd.ExecuteNonQuery();
                }
                _historialServicios.RegistrarAccion(new Historial
                {
                    fecha = DateTime.Now,
                    controlador = "Eliminar Categoria",
                    observacion = "Se elimino una categoria",
                    elemento = "Categoria: " + catId.ToString()
                });
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }
    }
}