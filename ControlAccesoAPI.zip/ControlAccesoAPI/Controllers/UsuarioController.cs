﻿using ControlAcceso.Modelos;
using static ControlAcceso.Funciones.Funciones;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.Json.Serialization;
using System.Net.Http;
using System.Security.Cryptography;

namespace ControlAcceso.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private readonly string _conexionSQL;
        public UsuarioController(IConfiguration config)
        {
            _conexionSQL = config.GetConnectionString("ConexionBDSQL");
        }

        [HttpPost]
        [Route("Crear")]
        public IActionResult Crear([FromBody] Usuario nuevoUsuario)
        {
            try
            {
                nuevoUsuario.usuId = rutToId(nuevoUsuario.user_rut);
                nuevoUsuario.user_rut = cleanRut(nuevoUsuario.user_rut);
                nuevoUsuario.creation_date = DateTime.Now;

                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Usuario", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@usuId", nuevoUsuario.usuId);
                    cmd.Parameters.AddWithValue("@usuNombre", nuevoUsuario.usuNombre);
                    cmd.Parameters.AddWithValue("@user_rut", nuevoUsuario.user_rut);
                    cmd.Parameters.AddWithValue("@user_phone", nuevoUsuario.user_phone);
                    cmd.Parameters.AddWithValue("@user_email", nuevoUsuario.user_email);
                    cmd.Parameters.AddWithValue("@user_catId", nuevoUsuario.user_category.catId);
                    cmd.Parameters.AddWithValue("@user_faculty_id", nuevoUsuario.user_faculty.facu_id);
                    cmd.Parameters.AddWithValue("@user_university", nuevoUsuario.user_university);
                    cmd.Parameters.AddWithValue("@user_role_id", nuevoUsuario.user_role.rol_id);
                    cmd.Parameters.AddWithValue("@creation_date", nuevoUsuario.creation_date);
                    cmd.Parameters.AddWithValue("@creator_user_id", nuevoUsuario.creator_user_id);
                    cmd.Parameters.AddWithValue("@start_date", nuevoUsuario.start_date);
                    cmd.Parameters.AddWithValue("@end_date", nuevoUsuario.end_date);
                    cmd.Parameters.AddWithValue("@user_status", nuevoUsuario.user_status);
                    cmd.Parameters.AddWithValue("@modo", "C");

                    cmd.ExecuteNonQuery();
                }

                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpGet]
        [Route("VerificarRelacion")]
        public IActionResult VerificarRelacion(string usuId, int place_id)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM UsuarioLugar WHERE usuId = @usuId AND place_id = @place_id", connSQL);
                    cmd.Parameters.AddWithValue("@usuId", usuId);
                    cmd.Parameters.AddWithValue("@place_id", place_id);

                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        return Ok(new { mensaje = "Existe una relación" });
                    }
                    else
                    {
                        return Ok(new { mensaje = "No existe una relación" });
                    }
                }
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpGet]
        [Route("Lista")]
        public IActionResult Lista(int? facultad = null, string? universidad = null, string? estado = null, int? catId = null, int? rolId = null)
        {
            List<Usuario> lUsuarios = new List<Usuario>(); 
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Usuario", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@modo", "L");

                    if (facultad.HasValue)
                        cmd.Parameters.AddWithValue("@user_faculty_id", facultad.Value);
                    if (!string.IsNullOrEmpty(universidad))
                        cmd.Parameters.AddWithValue("@user_university", universidad);
                    if (!string.IsNullOrEmpty(estado))
                        cmd.Parameters.AddWithValue("@user_status", estado);
                    if (catId.HasValue)
                        cmd.Parameters.AddWithValue("@user_catId", catId.Value);
                    if (rolId.HasValue)
                        cmd.Parameters.AddWithValue("@user_role_id", rolId.Value);
                                
                    using (SqlDataReader resultadoSP = cmd.ExecuteReader())
                    {
                        while (resultadoSP.Read())
                        {
                            int facu_id = Convert.ToInt32(resultadoSP["user_faculty_id"]);
                            Facultad facu = ObtenerFacultadPorId(facu_id);
                            int cat_id = Convert.ToInt32(resultadoSP["user_catId"]);
                            Categoria category = ObtenerCategoriaPorId(cat_id);
                            int rol_id = Convert.ToInt32(resultadoSP["user_role_id"]);
                            Rol rol = ObtenerRolPorId(rol_id);
                            string user_rut = resultadoSP["user_rut"].ToString();
                            string usuId = rutToId(user_rut);

                            lUsuarios.Add(new Usuario()
                            {
                                usuId = usuId,
                                usuNombre = resultadoSP[1].ToString(),
                                user_rut = resultadoSP[2].ToString(),
                                user_phone = resultadoSP[3].ToString(),
                                user_email = resultadoSP[4].ToString(),
                                user_category = category,
                                user_faculty = facu,
                                user_university = resultadoSP[7].ToString(),
                                user_role = rol,
                                creation_date = resultadoSP.GetDateTime(9),
                                creator_user_id = resultadoSP[10].ToString(),
                                start_date = resultadoSP.GetDateTime(11),
                                end_date = resultadoSP.GetDateTime(12),
                                user_status = resultadoSP[13].ToString(),
                            }); ;
                        }
                    }
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", lUsuarios = lUsuarios });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message, lUsuarios = lUsuarios });
            }
        }

        [HttpGet]
        [Route("Obtener")]
        public IActionResult Obtener(string usuId)
        {
            Usuario user_info = new Usuario();
            try
            {
                user_info = ObtenerUsuarioPorId(usuId);
                if(user_info == null) {
                    return StatusCode(StatusCodes.Status404NotFound, new { mensaje = "Usuario no encontrado" });
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", user = user_info });

            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message, user = user_info });
            }
        }
        private Usuario ObtenerUsuarioPorId(string usuId)
        {
            Usuario user_info = null;
            
            using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
            {
                connSQL.Open();
                SqlCommand cmd = new SqlCommand("Mantenedor_Usuario", connSQL);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@usuId", usuId);
                cmd.Parameters.AddWithValue("@modo", "G");

                using (SqlDataReader resultadoSP = cmd.ExecuteReader())
                {
                    if (resultadoSP.Read())
                    {
                        int facu_id = Convert.ToInt32(resultadoSP["user_faculty_id"]);
                        Facultad facu = ObtenerFacultadPorId(facu_id);
                        int cat_id = Convert.ToInt32(resultadoSP["user_catId"]);
                        Categoria category = ObtenerCategoriaPorId(cat_id);
                        int rol_id = Convert.ToInt32(resultadoSP["user_role_id"]);
                        Rol rol = ObtenerRolPorId(rol_id);
                        string user_rut = resultadoSP["user_rut"].ToString();
                        string user_id = rutToId(user_rut);

                        user_info = new Usuario()
                        {
                            usuId = user_id,
                            usuNombre = resultadoSP[1].ToString(),
                            user_rut = resultadoSP[2].ToString(),
                            user_phone = resultadoSP[3].ToString(),
                            user_email = resultadoSP[4].ToString(),
                            user_category = category,
                            user_faculty = facu,
                            user_university = resultadoSP[7].ToString(),
                            user_role = rol,
                            creation_date = resultadoSP.GetDateTime(9),
                            creator_user_id = resultadoSP[10].ToString(),
                            start_date = resultadoSP.IsDBNull(11) ? (DateTime?)null : resultadoSP.GetDateTime(11),
                            end_date = resultadoSP.IsDBNull(12) ? (DateTime?)null : resultadoSP.GetDateTime(12),
                            user_status = resultadoSP[13].ToString(),
                        };
                    }
                }
            }
         
            return user_info;
        }



        [HttpPut]
        [Route("Modificar")]
        public IActionResult Modificar([FromBody] Usuario usuario)
        {
            try
            {
                usuario.usuId = rutToId(usuario.user_rut);
                usuario.user_rut = cleanRut(usuario.user_rut);

                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Usuario", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@usuId", usuario.usuId);
                    cmd.Parameters.AddWithValue("@usuNombre", usuario.usuNombre);
                    cmd.Parameters.AddWithValue("@user_rut", usuario.user_rut);
                    cmd.Parameters.AddWithValue("@user_phone", usuario.user_phone);
                    cmd.Parameters.AddWithValue("@user_email", usuario.user_email);
                    cmd.Parameters.AddWithValue("@user_catId", usuario.user_category.catId);
                    cmd.Parameters.AddWithValue("@user_faculty_id", usuario.user_faculty.facu_id);
                    cmd.Parameters.AddWithValue("@user_university", usuario.user_university);
                    cmd.Parameters.AddWithValue("@user_role_id", usuario.user_role.rol_id);
                    /* Se pidio no modificar:
                    cmd.Parameters.AddWithValue("@creation_date", usuario.creation_date);
                    cmd.Parameters.AddWithValue("@creator_user_id", usuario.creator_user_id);*/
                    cmd.Parameters.AddWithValue("@start_date", usuario.start_date);
                    cmd.Parameters.AddWithValue("@end_date", usuario.end_date);
                    cmd.Parameters.AddWithValue("@user_status", usuario.user_status);

                    cmd.Parameters.AddWithValue("@modo", "M");
                    cmd.ExecuteNonQuery();
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpDelete]
        [Route("Eliminar")]
        public IActionResult Eliminar(string usuId)
        {
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Usuario", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@usuId", usuId);
                    cmd.Parameters.AddWithValue("@modo", "D");
                    cmd.ExecuteNonQuery();
                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpGet]
        [Route("Contar")]
        public IActionResult Contar(int? facultad = null, string? universidad = null, string? estado = null, int? catId = null, int? rolId = null)
        {
            int cantidad = 0;
            try
            {
                using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
                {
                    connSQL.Open();
                    SqlCommand cmd = new SqlCommand("Mantenedor_Usuario", connSQL);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@modo", "N");


                    if (facultad.HasValue)
                        cmd.Parameters.AddWithValue("@user_faculty_id", facultad);
                    if (!string.IsNullOrEmpty(universidad))
                        cmd.Parameters.AddWithValue("@user_university", universidad);
                    if (!string.IsNullOrEmpty(estado))
                        cmd.Parameters.AddWithValue("@user_status", estado);
                    if (catId.HasValue)
                        cmd.Parameters.AddWithValue("@user_catId", catId.Value);
                    if (rolId.HasValue)
                        cmd.Parameters.AddWithValue("@user_role_id", rolId.Value);

                    cantidad = (int)cmd.ExecuteScalar();

                }
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "Ok", cantidad = cantidad });
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

        [HttpGet]
        [Route("VerificarFechaTermino")]
        public IActionResult VerificarFechaTermino(string usuId)
        {
            try
            {
                Usuario usuario = ObtenerUsuarioPorId(usuId);

                if (usuario == null)
                {
                    return StatusCode(StatusCodes.Status404NotFound, new { mensaje = "Usuario no encontrado" });
                }

                if (usuario.end_date.HasValue && DateTime.Now > usuario.end_date.Value)
                {
                    return StatusCode(StatusCodes.Status200OK, new { mensaje = "Fecha de término alcanzada" });
                }
                else
                {
                    return StatusCode(StatusCodes.Status200OK, new { mensaje = "Fecha de término no alcanzada" });
                }
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { mensaje = error.Message });
            }
        }

    }
}