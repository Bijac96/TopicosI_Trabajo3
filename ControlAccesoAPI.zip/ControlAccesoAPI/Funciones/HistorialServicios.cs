﻿using System.Data.SqlClient;
using ControlAcceso.Modelos;

namespace ControlAcceso.Funciones
{
    public interface IHistorialServicios
    {
        void RegistrarAccion(Historial historial);
    }

    public class HistorialServicios : IHistorialServicios
    {
        private readonly string _conexionSQL;

        public HistorialServicios(IConfiguration config)
        {
            _conexionSQL = config.GetConnectionString("ConexionBDSQL");
        }

        public void RegistrarAccion(Historial historial)
        {
            using (SqlConnection connSQL = new SqlConnection(_conexionSQL))
            {
                connSQL.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Historial (fecha, controlador, observacion, elemento) VALUES (@fecha, @controlador, @observacion, @elemento)", connSQL);
                cmd.Parameters.AddWithValue("@fecha", historial.fecha);
                cmd.Parameters.AddWithValue("@controlador", historial.controlador);
                cmd.Parameters.AddWithValue("@observacion", historial.observacion);
                cmd.Parameters.AddWithValue("@elemento", historial.elemento);

                cmd.ExecuteNonQuery();
            }
        }
    }
}
