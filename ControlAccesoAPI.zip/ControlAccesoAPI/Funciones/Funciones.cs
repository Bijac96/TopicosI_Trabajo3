﻿using ControlAcceso.Modelos;
using System.Data.SqlClient;

namespace ControlAcceso.Funciones
{
    public static class Funciones
    {
        public static string rutToId(string rut)
        {
            return rut.Replace(".", "").Replace("-", "");
        }

        public static string cleanRut(string rut)
        {
            return rut.Replace(".", "");
        }
        public static Facultad ObtenerFacultadPorId(int facu_id)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=B_ALONSO\\SQLEXPRESS01;Initial Catalog=TopicosI;trusted_connection=true"))
            {
                conn.Open();

                string query = "SELECT * FROM Facultad WHERE facu_id=@facu_id;";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@facu_id", facu_id);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Facultad
                        {
                            facu_id = reader.GetInt32(reader.GetOrdinal("facu_id")),
                            facu_name = reader.GetString(reader.GetOrdinal("facu_name"))
                        };
                    }
                    else
                    {
                        return null;
                    }
                }
            }
        }
        public static Categoria ObtenerCategoriaPorId(int cat_id)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=B_ALONSO\\SQLEXPRESS01;Initial Catalog=TopicosI;trusted_connection=true"))
            {
                conn.Open();

                string query = "SELECT * FROM Categoria WHERE catId=@catId;";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@catId", cat_id);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Categoria
                        {
                            catId = reader.GetInt32(reader.GetOrdinal("catId")),
                            cat_name = reader.GetString(reader.GetOrdinal("cat_name"))
                        };
                    }
                    else
                    {
                        return null;
                    }
                }
            }
        }

        public static Rol ObtenerRolPorId(int rol_id)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=B_ALONSO\\SQLEXPRESS01;Initial Catalog=TopicosI;trusted_connection=true"))
            {
                conn.Open();

                string query = "SELECT * FROM Rol WHERE rol_id=@rol_id;";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@rol_id", rol_id);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Rol
                        {
                            rol_id = reader.GetInt32(reader.GetOrdinal("rol_id")),
                            rol_name = reader.GetString(reader.GetOrdinal("rol_name"))
                        };
                    }
                    else
                    {
                        return null;
                    }
                }
            }
        }

    }
}
