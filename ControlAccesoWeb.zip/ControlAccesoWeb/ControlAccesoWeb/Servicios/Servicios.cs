﻿using ControlAcceso.Modelos;
using ControlAccesoWeb.Models;
using Newtonsoft.Json;
using System;
using System.Text;

namespace ControlAccesoWeb.Servicios
{
    public class Servicios : IServicios
    {

        /*  LISTAR    */

        public async Task<List<Usuario>> ListaUsuarios()
        {
            List<Usuario> lUsuario = new List<Usuario>();
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.GetAsync("api/Usuario/Lista");
            if (response.IsSuccessStatusCode){
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var resultado = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                lUsuario = resultado.user_list;
            }
            return lUsuario;
        }

        public async Task<List<Rol>> ListaRoles()
        {
            List<Rol> lRoles = new List<Rol>();
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.GetAsync("api/Rol/Lista");
            if (response.IsSuccessStatusCode)
            {
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var resultado = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                lRoles = resultado.rol_list;
            }
            return lRoles;
        }

        public async Task<List<Categoria>> ListaCategorias()
        {
            List<Categoria> lCategorias = new List<Categoria>();
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.GetAsync("api/Categoria/Lista");
            if (response.IsSuccessStatusCode)
            {
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var resultado = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                lCategorias = resultado.cat_list;
            }
            return lCategorias;
        }

        public async Task<List<Facultad>> ListaFacultades()
        {
            List<Facultad> lFacultad = new List<Facultad>();
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.GetAsync("api/Facultad/Lista");
            if (response.IsSuccessStatusCode){
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var resultado = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                lFacultad = resultado.facu_list;
            }
            return lFacultad;
        }

        public async Task<List<Lugar>> ListaLugares()
        {
            List<Lugar> lLugares = new List<Lugar>();
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.GetAsync("api/Lugar/Lista");
            if (response.IsSuccessStatusCode)
            {
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var resultado = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                lLugares = resultado.place_list;
            }
            return lLugares;
        }


        /*  CREAR   */

        public async Task<bool> CrearUsuario(Usuario user)
        {
            var cliente = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.PostAsync($"api/Usuario/Crear/", content);
            
            return response.IsSuccessStatusCode;
        }
        
    
        public async Task<bool> CrearRol(Rol rol)
        {
            var cliente = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(rol), Encoding.UTF8, "application/json");

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.PostAsync($"api/Rol/Crear/", content);
            
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> CrearCategoria(Categoria cat)
        {
            var cliente = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(cat), Encoding.UTF8, "application/json");

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.PostAsync($"api/Categoria/Crear/", content);
            
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> CrearFacultad(Facultad facu)
        {
            var cliente = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(facu), Encoding.UTF8, "application/json");

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.PostAsync($"api/Facultad/Crear/", content);
            
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> CrearLugar(Lugar place)
        {
            var cliente = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(place), Encoding.UTF8, "application/json");

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.PostAsync($"api/Lugar/Crear/", content);

            return response.IsSuccessStatusCode;
        }


        /*  MODIFICAR */
        public async Task<bool> ModificarUsuario(Usuario user)
        {
            var cliente = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");
            
            cliente.BaseAddress = new Uri("https://localhost:7175");
            
            var response = await cliente.PutAsync($"api/Usuario/Modificar/", content);
            
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> ModificarRol(Rol rol)
        {
            var cliente = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(rol), Encoding.UTF8, "application/json");

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.PutAsync($"api/Rol/Modificar/", content);
            
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> ModificarCategoria(Categoria cat)
        {
            var cliente = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(cat), Encoding.UTF8, "application/json");

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.PutAsync("api/Categoria/Modificar/", content);

            return response.IsSuccessStatusCode;
        }

        public async Task<bool> ModificarFacultad(Facultad facu)
        {
            var cliente = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(facu), Encoding.UTF8, "application/json");
            
            cliente.BaseAddress = new Uri("https://localhost:7175");
            
            var response = await cliente.PutAsync($"api/Facultad/Modificar/", content);
            
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> ModificarLugar(Lugar place)
        {
            var cliente = new HttpClient();
            var content = new StringContent(JsonConvert.SerializeObject(place), Encoding.UTF8, "application/json");

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.PutAsync("api/Lugar/Modificar/", content);

            return response.IsSuccessStatusCode;
        }



        /*  ELIMINAR    */

        public async Task<bool> EliminarUsuario(String usuId)
        {
            var cliente = new HttpClient();
            
            cliente.BaseAddress = new Uri("https://localhost:7175");
            
            var response = await cliente.DeleteAsync($"api/Usuario/Eliminar/?usuId={usuId}");
            
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> EliminarRol(int rolId)
        {
            var cliente = new HttpClient();

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.DeleteAsync($"api/Rol/Eliminar/?rol_id={rolId}");
            if (response.IsSuccessStatusCode)
            {
                return true;
            }
            return false;
        }

        public async Task<bool> EliminarCategoria(int catId)
        {
            var cliente = new HttpClient();

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.DeleteAsync($"api/Categoria/Eliminar/?catId={catId}");

            return response.IsSuccessStatusCode;
        }

        public async Task<bool> EliminarFacultad(int facId)
        {
            var cliente = new HttpClient();

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.DeleteAsync($"api/Facultad/Eliminar/?facu_id={facId}");

            return response.IsSuccessStatusCode;
        }

        public async Task<bool> EliminarLugar(int place_id)
        {
            var cliente = new HttpClient();

            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.DeleteAsync($"api/Lugar/Eliminar/?place_id={place_id}");

            return response.IsSuccessStatusCode;
        }



        /*  OBTENER */

        public async Task<Usuario> ObtenerUsuario(String usuId)
        {
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.GetAsync($"api/Usuario/Obtener/?usuId={usuId}");
            if (response.IsSuccessStatusCode)
            {
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var apiResponse = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                var oUsuarioO = apiResponse.user;
                return oUsuarioO;
                
            }
            return null;
        }

        public async Task<Rol> ObtenerRol(int rolId)
        {
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.GetAsync($"api/Rol/Obtener/?rol_id={rolId}");
            if (response.IsSuccessStatusCode)
            {
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var apiResponse = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                var oRolO = apiResponse.rol;
                return oRolO;
            }
            return null;
        }

        public async Task<Categoria> ObtenerCategoria(int catId)
        {
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.GetAsync($"api/Categoria/Obtener/?catId={catId}");
            if (response.IsSuccessStatusCode)
            {
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var apiResponse = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                var oTipoCategoriaO = apiResponse.categoria;
                return oTipoCategoriaO;
            }
            return null;
        }

        public async Task<Facultad> ObtenerFacultad(int facId)
        {
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.GetAsync($"api/Facultad/Obtener/?facu_id={facId}");
            if (response.IsSuccessStatusCode)
            {
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var apiResponse = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                var oFacultadO = apiResponse.facultad;
                return oFacultadO;
            }
            return null;
        }

        public async Task<Lugar> ObtenerLugar(int place_id)
        {
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            var response = await cliente.GetAsync($"api/Lugar/Obtener/?place_id={place_id}");
            if (response.IsSuccessStatusCode)
            {
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var apiResponse = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                var oLugarO = apiResponse.place;
                return oLugarO;
            }
            return null;
        }


        /*  OTROS   */

        public async Task<int> ContarUsuarios(int? facultad = null, string? universidad = null, string? estado = null, int? tipoId = null, int? rolId = null)
        {
            var cliente = new HttpClient();
            cliente.BaseAddress = new Uri("https://localhost:7175");

            string filtro = $"api/Usuario/Contar?";
            if (facultad.HasValue)
                filtro += $"facultad={facultad}&";
            if (!string.IsNullOrEmpty(universidad))
                filtro += $"universidad={universidad}&";
            if (!string.IsNullOrEmpty(estado))
                filtro += $"estado={estado}&";
            if (tipoId.HasValue)
                filtro += $"tipoId={tipoId}&";
            if (rolId.HasValue)
                filtro += $"rolId={rolId}&";

            var response = await cliente.GetAsync(filtro.TrimEnd('&'));
            if (response.IsSuccessStatusCode)
            {
                var json_respuesta = await response.Content.ReadAsStringAsync();
                var respuesta = JsonConvert.DeserializeObject<RespuestaAPI>(json_respuesta);
                return respuesta.cantidad;
            }
            return 0;
        }
    }
}