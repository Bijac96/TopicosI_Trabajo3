﻿using ControlAcceso.Modelos;
using ControlAccesoWeb.Models;
using System;

namespace ControlAccesoWeb.Servicios
{
    public interface IServicios
    {
        /*  LISTAR    */
        Task<List<Usuario>> ListaUsuarios();
        Task<List<Rol>> ListaRoles();
        Task<List<Categoria>> ListaCategorias();
        Task<List<Facultad>> ListaFacultades();
        Task<List<Lugar>> ListaLugares();

        /*  CREAR   */
        Task<bool> CrearUsuario(Usuario user);
        Task<bool> CrearRol(Rol rol);
        Task<bool> CrearCategoria(Categoria cat);
        Task<bool> CrearFacultad(Facultad facu);
        Task<bool> CrearLugar(Lugar place);

        /*  MODIFICAR */
        Task<bool> ModificarUsuario(Usuario user);
        Task<bool> ModificarRol(Rol rol);
        Task<bool> ModificarCategoria(Categoria cat);
        Task<bool> ModificarFacultad(Facultad facu);
        Task<bool> ModificarLugar(Lugar place);

        /*  ELIMINAR  */
        Task<bool> EliminarUsuario(String usuId);
        Task<bool> EliminarRol(int rolId);
        Task<bool> EliminarCategoria(int catId);
        Task<bool> EliminarFacultad(int facId);
        Task<bool> EliminarLugar(int place_id);

        /*  OBTENER */
        Task<Usuario> ObtenerUsuario(String usuId);
        Task<Rol> ObtenerRol(int rolId);
        Task<Categoria> ObtenerCategoria(int catId);
        Task<Facultad> ObtenerFacultad(int facId);
        Task<Lugar> ObtenerLugar(int place_id);

        /*  OTROS   */
        Task<int> ContarUsuarios(int? facultad = null, string universidad = null, string estado = null, int? tipoId = null, int? rolId = null);
    }
}
