﻿using ControlAccesoWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net;
using System.Text;
using ControlAccesoWeb.Servicios;
using System;
using Microsoft.AspNetCore.Mvc.Rendering;
using ControlAcceso.Modelos;

namespace ControlAccesoWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly IServicios _serviciosApi;
        public HomeController(IServicios serviciosApi)
        {
            _serviciosApi = serviciosApi;
        }
        public async Task<IActionResult> Index()
        {
            //Usuario oUsuario = new Usuario() { usuId = "111111111", user_rut = "11111111-1", usuNombre = "Prueba", user_category = new Categoria() { catId = 1 }, user_faculty = new Facultad() { facu_id = 1 },
            //    user_university = "UMAG", user_role = new Rol() { rol_id = 1 }, creator_user_id = "555555555", start_date = new DateTime(2024, 01, 01), end_date = new DateTime(2024, 12, 31), user_status = "A"
            //};

            //Usuario oUsuario2 = new Usuario() { usuId = "222222222", user_rut = "22222222-2", usuNombre = "Chau", user_phone = "22", user_email = "chau@umag.cl", user_category = new Categoria() { catId = 2 }, user_faculty = new Facultad() { facu_id = 2 },
            //    user_university = "inacap", user_role = new Rol() { rol_id = 2 }, creator_user_id = "555555555", start_date = new DateTime(2024, 01, 01), end_date = new DateTime(2024, 12, 31), user_status = "I"
            //};

            //Usuario oUsuario3 = new Usuario() { usuId = "333333333", user_rut = "33333333-3", usuNombre = "Hola", user_category = new Categoria() { catId = 1 }, user_faculty = new Facultad() { facu_id = 1 },
            //    user_university = "umag", user_role = new Rol() { rol_id = 1 }, creator_user_id = "555555555", start_date = new DateTime(2024, 01, 01), end_date = new DateTime(2024, 12, 31), user_status = "I"
            //};
            /*** 
            * 
            * CONEXION A LA API PARA LA CREACION DE LOS USUARIOS NUEVOS 
            * 
            * ***/
            //await _serviciosApi.CrearUsuario(oUsuario);
            //await _serviciosApi.CrearUsuario(oUsuario2);
            //await _serviciosApi.CrearUsuario(oUsuario3);



            //Usuario oMUsuario = new Usuario() { usuId = "111111111", user_rut = "11111111-1", usuNombre = "PruebaM", user_category = new Categoria() { catId = 3 }, user_faculty = new Facultad() { facu_id = 2 },
            //    user_university = "UMAG", user_role = new Rol() { rol_id = 2 }, creator_user_id = "555555555", start_date = new DateTime(2024, 01, 01), end_date = new DateTime(2024, 12, 31), user_status = "A"
            //};
            /*** 
             * 
             * CONEXION A LA API PARA LA MODIFICACION DEL USUARIO
             * 
             * ***/
            //await _serviciosApi.ModificarUsuario(oMUsuario);



            /***
             * 
             * CONEXION A LA API PARA QUE SE ELIMINE EL USUARIO DE ID 333333333
             * 
             * ***/
            //await _serviciosApi.EliminarUsuario("333333333");



            //Usuario oUsuarioO = new Usuario();
            /*** 
             * 
             * CONEXION A LA API PARA OBTENER LOS DATOS DEL USUARIO DE ID 111111111 Y SE GUARDEN EN LA VARIABLE "oUsuarioO"
             * 
             * ***/
            //oUsuarioO = await _serviciosApi.ObtenerUsuario("111111111");



            //List<Usuario> lUsuario = new List<Usuario>();
            /***
             * 
             * CONEXION A LA API PARA OBTENER LA LISTA DE USUARIOS Y SE GUARDEN EN LA VARIABLE "lUsuario"
             * 
             * ***/
            //lUsuario = await _serviciosApi.ListaUsuarios();



            //int facFiltro = 1;string uniFiltro = "umag"; string estadoFiltro = null; int tcFiltro = 0;int rolFiltro = 1;
            ///***
            // * 
            // * CONEXION A LA API PARA CONTAR LA CANTIDAD DE USUARIOS SEGÚN LOS FILTROS PROVISTOS CON ANTERIORIDAD
            // * 
            // * ***/
            //int cantidad = await _serviciosApi.ContarUsuarios(facFiltro, uniFiltro, estadoFiltro, tcFiltro, rolFiltro);
            //Console.WriteLine($"Cantidad de usuarios: {cantidad}");



            //facFiltro = 0; uniFiltro = null; estadoFiltro = null; tcFiltro = 0; rolFiltro = 0;
            /***
             * 
             * conexion a la api para contar la cantidad de usuarios sin filtros
             * 
             * ***/
            //cantidad = await _serviciosApi.ContarUsuarios(facFiltro, uniFiltro, estadoFiltro, tcFiltro, rolFiltro);
            //Console.WriteLine($"Cantidad de usuarios sin filtros: {cantidad}");




            //Facultad oFacultad = new Facultad() { facu_id = 1, facu_name = "INGENIERIA" };
            //Facultad oFacultad2 = new Facultad() { facu_id = 2, facu_name = "ENFERMERIA" };
            //Facultad oFacultad3 = new Facultad() { facu_id = 3, facu_name = "SIENSIAS" };
            //Facultad oFacultad4 = new Facultad() { facu_id = 4, facu_name = "HUMANIDADES" };
            /***
             * 
             * CONEXION A LA API PARA LA CREACION DE FACULTADES
             * 
             * ***/
            //await _serviciosApi.CrearFacultad(oFacultad);
            //await _serviciosApi.CrearFacultad(oFacultad2);
            //await _serviciosApi.CrearFacultad(oFacultad3);
            //await _serviciosApi.CrearFacultad(oFacultad4);



            //Facultad oFacultad3M = new Facultad() { facu_id = 3, facu_name = "CIENCIAS" };
            /***
             * 
             * CONEXION A LA API PARA LA MODIFICACION DE LA FACULTAD 
             * 
             * ***/
            //await _serviciosApi.ModificarFacultad(oFacultad3M);



            /*** 
             * 
             * CONEXION A LA API PARA ELIMINAR LA FACULTAD DE ID 4 
             * 
             * ***/
            //await _serviciosApi.EliminarFacultad(4);



            //Facultad oFacultadO = new Facultad();
            /***
             * 
             * CONEXION A LA API PARA LA OBTENCION DE LA INFORMACION DE LA FACULTAD DE ID 1 Y SE GUARDE EN LA VARIABLE "oFacultadO"
             * 
             * ***/
            //oFacultadO = await _serviciosApi.ObtenerFacultad(1);



            //List<Facultad> lFacultad = new List<Facultad>();
            /***
             * 
             * CONEXION A LA API PARA LISTAR LAS FACULTADES
             * 
             * ***/
            //lFacultad = await _serviciosApi.ListaFacultades();



            //Rol oRol = new Rol() { rol_id = 1, rol_name = "ALUMNO" };
            //Rol oRol2 = new Rol() { rol_id = 2, rol_name = "PROFESOR" };
            //Rol oRol3 = new Rol() { rol_id = 3, rol_name = "ADMINISTADOR" };
            //Rol oRol4 = new Rol() { rol_id = 4, rol_name = "INVITADO" };
            /***
             * 
             * CONEXION A LA API PARA LA CREACION DE LOS ROLES
             * 
             * ***/
            //await _serviciosApi.CrearRol(oRol);
            //await _serviciosApi.CrearRol(oRol2);
            //await _serviciosApi.CrearRol(oRol3);
            //await _serviciosApi.CrearRol(oRol4);



            //Rol oRol3M = new Rol() { rol_id = 3, rol_name = "ADMINISTRADOR" };
            /***
             * 
             * CONEXION A LA API PARA LA MODIFICACION DEL ROL 
             * 
             * ***/
            //await _serviciosApi.ModificarRol(oRol3M);



            /*** 
             * 
             * CONEXION A LA API PARA ELIMINAR EL ROL DE ID 4 
             * 
             * ***/
            //await _serviciosApi.EliminarRol(4);



            //Rol oRolO = new Rol();
            /***
             * 
             * CONEXION A LA API PARA LA OBTENCION DE LA INFORMACION DEL ROL DE ID 3 Y SE GUARDE EN LA VARIABLE "oRolO"
             * 
             * ***/
            //oRolO = await _serviciosApi.ObtenerRol(3);



            //List<Rol> Rol = new List<Rol>();
            /***
             * 
             * CONEXION A LA API PARA LISTAR LOS ROLES
             * 
             * ***/
            //Rol = await _serviciosApi.ListaRoles();



            //Categoria oTipoCategoriad = new Categoria() { catId = 1, cat_name = "UNIVERSITARIO" };
            //Categoria oTipoCategoria2 = new Categoria() { catId = 2, cat_name = "EXTERNOS" };
            //Categoria oTipoCategoria3 = new Categoria() { catId = 3, cat_name = "INVITADO" };
            //Categoria oTipoCategoria4 = new Categoria() { catId = 4, cat_name = "ADMINIST" };
            /***
             * 
             * CONEXION A LA API PARA LA CREACION DE LOS TIPOCATEGORIA
             * 
             * ***/
            //await _serviciosApi.CrearCategoria(oTipoCategoriad);
            //await _serviciosApi.CrearCategoria(oTipoCategoria2);
            //await _serviciosApi.CrearCategoria(oTipoCategoria3);
            //await _serviciosApi.CrearCategoria(oTipoCategoria4);


            //Categoria oTipoCategoriaM = new Categoria() { catId = 4, cat_name = "ADMINISTRATIVO" };
            /***
             * 
             * CONEXION A LA API PARA LA MODIFICACION DEL TIPOCATEGORIA
             * 
             * ***/
            //await _serviciosApi.ModificarCategoria(oTipoCategoriaM);



            /*** 
             * 
             * CONEXION A LA API PARA ELIMINAR EL TIPOCATEGORIA DE ID 2
             * 
             * ***/
            //await _serviciosApi.EliminarCategoria(2);



            //Categoria oTipoCategoriaO = new Categoria();
            /***
             * 
             * CONEXION A LA API PARA LA OBTENCION DE LA INFORMACION DEL TIPOCATEGORIA DE ID 3 Y SE GUARDE EN LA VARIABLE "oTipoCategoriaO"
             * 
             * ***/
            //oTipoCategoriaO = await _serviciosApi.ObtenerCategoria(3);



            //List<Categoria> lTipoCategoria = new List<Categoria>();
            /***
             * 
             * CONEXION A LA API PARA LISTAR LOS TIPOCATEGORIA
             * 
             * ***/
            //lTipoCategoria = await _serviciosApi.ListaCategorias();

            return View();
        }

        public async Task<IActionResult> MantenedorUsuario()
        {
            List<Usuario> lUsuario = await _serviciosApi.ListaUsuarios();
            return View("Mantenedores/MantenedorUsuario", lUsuario);
        }

        public IActionResult CrearUsuarioForm()
        {
            return View("FormularioCrear/CrearUsuario");
        }

        public IActionResult ModificarUsuarioForm(String user_id, String user_rut)
        {
            Usuario user = new Usuario() { usuId = user_id , user_rut = user_rut};
            return View("FormularioModificar/ModificarUsuario", user);
        }
        
        public async Task<IActionResult> CrearUsuario(Usuario user)
        {
            bool respuesta = await _serviciosApi.CrearUsuario(user);
            if (respuesta)
            {
                return RedirectToAction("Mantenedores/MantenedorUsuario");
            }
            else
            {
                return View("FormularioCrear/CrearUsuario", user);
            }
        }
        
        public async Task<IActionResult> BuscarUsuario(String user_id)
        {
            Usuario user = await _serviciosApi.ObtenerUsuario(user_id);
            return View("Detalle/DetalleUsuario", user);
        }
        
        public async Task<IActionResult> ModificarUsuario(Usuario user)
        {
            bool respuesta = await _serviciosApi.ModificarUsuario(user);
            if (respuesta)
            {
                return RedirectToAction("Mantenedores/MantenedorUsuario");
            }
            else
            {
                return View("FormularioModificar/ModificarUsuario", user);
            }
        }
       
        public async Task<IActionResult> EliminarUsuario(String user_id)
        {
            bool respuesta = false;
            respuesta = await _serviciosApi.EliminarUsuario(user_id);
            if (respuesta)
            {
                return RedirectToAction("Mantenedores/MantenedorUsuario");
            }
            else
            {
                return View("Mantenedores/MantenedorUsuario");
            }
        }

        
        
        public async Task<IActionResult> MantenedorFacultad()
        {
            List<Facultad> lFacultad = await _serviciosApi.ListaFacultades();
            return View("Mantenedores/MantenedorFacultad", lFacultad);
        }

        [HttpGet]
        public IActionResult CrearFacultadForm()
        {
            return View("FormularioCrear/CrearFacultad");
        }
        
        public IActionResult ModificarFacultadForm(int facu_id)
        {
            Facultad facu = new Facultad() { facu_id = facu_id };
            return View("FormularioModificar/ModificarFacultad", facu);
        }

        public async Task<IActionResult> CrearFacultad(Facultad facu)
        {
            bool respuesta = await _serviciosApi.CrearFacultad(facu);
            if (respuesta)
            {
                return RedirectToAction("MantenedorFacultad");
            }
            else
            {
                return View("FormularioCrear/CrearFacultad", facu);
            }
        }

        public async Task<IActionResult> BuscarFacultad(int facu_id)
        {
            Facultad facu = await _serviciosApi.ObtenerFacultad(facu_id);
            return View("Detalle/DetalleFacultad", facu);
        }
        
        public async Task<IActionResult> ModificarFacultad(Facultad facu)
        {
            bool respuesta = await _serviciosApi.ModificarFacultad(facu);
            if (respuesta)
            {
                return RedirectToAction("MantenedorFacultad");
            }
            else
            {
                return View("FormularioModificar/ModificarFacultad", facu);
            }
        }
        
        public async Task<IActionResult> EliminarFacultad(int facu_id)
        {
            bool respuesta = false;
            respuesta = await _serviciosApi.EliminarFacultad(facu_id);
            if (respuesta)
            {
                return RedirectToAction("MantenedorFacultad");
            }
            else
            {
                return View("MantenedorFacultad");
            }
        }



        public async Task<IActionResult> MantenedorRol()
        {
            List<Rol> lRol = await _serviciosApi.ListaRoles();
            return View("Mantenedores/MantenedorRol", lRol);
        }

        [HttpGet]
        public IActionResult CrearRolForm()
        {
            return View("FormularioCrear/CrearRol");
        }

        public IActionResult ModificarRolForm(int rol_id)
        {
            Rol rol= new Rol() { rol_id = rol_id };
            return View("FormularioModificar/ModificarRol", rol);
        }

        [HttpPost]
        public async Task<IActionResult> CrearRol(Rol rol)
        {
            bool respuesta = await _serviciosApi.CrearRol(rol);
            if (respuesta)
            {
                return RedirectToAction("Mantenedores/MantenedorRol");
            }
            else
            {
                return View("FormularioCrear/CrearRol", rol);
            }
        }

        public async Task<IActionResult> BuscarRol(int rol_id)
        {
            Rol rol = await _serviciosApi.ObtenerRol(rol_id);
            return View("Detalle/DetalleRol", rol);
        }

        public async Task<IActionResult> ModificarRol(Rol rol)
        {
            bool respuesta = await _serviciosApi.ModificarRol(rol);
            if (respuesta)
            {
                return RedirectToAction("Mantenedores/MantenedorRol");
            }
            else
            {
                return View("FormularioModificar/ModificarRol", rol);
            }
        }

        public async Task<IActionResult> EliminarRol(int rolId)
        {
            bool respuesta = false;
            respuesta = await _serviciosApi.EliminarRol(rolId);
            if (respuesta)
            {
                return RedirectToAction("MantenedorRol");
            }
            else
            {
                return View("Mantenedores/MantenedorRol");
            }
        }



        public async Task<IActionResult> MantenedorCategoria()
        {
            List<Categoria> lCategoria = await _serviciosApi.ListaCategorias();
            return View("Mantenedores/MantenedorCategoria", lCategoria);
        }

        public IActionResult CrearCategoriaForm()
        {
            return View("FormularioCrear/CrearCategoria");
        }

        public IActionResult ModificarCategoriaForm(int cat_id)
        {
            Categoria cat = new Categoria() { catId = cat_id };
            return View("FormularioModificar/ModificarCategoria", cat);
        }

        public async Task<IActionResult> CrearCategoria(Categoria cat)
        {
            bool respuesta = await _serviciosApi.CrearCategoria(cat);
            if (respuesta)
            {
                return RedirectToAction("Mantenedores/MantenedorCategoria");
            }
            else
            {
                return View("FormularioCrear/CrearCategoria", cat);
            }
        }

        public async Task<IActionResult> BuscarCategoria(int cat_id)
        {
            Categoria cat = await _serviciosApi.ObtenerCategoria(cat_id);
            return View("Detalle/DetalleCategoria", cat);
        }

        public async Task<IActionResult> ModificarCategoria(Categoria cat)
        {
            bool respuesta = await _serviciosApi.ModificarCategoria(cat);
            if (respuesta)
            {
                return RedirectToAction("Mantenedores/MantenedorCategoria");
            }
            else
            {
                return View("FormularioModificar/ModificarCategoria", cat);
            }
        }
        
        public async Task<IActionResult> EliminarCategoria(int cat_id)
        {
            bool respuesta = false;
            respuesta = await _serviciosApi.EliminarCategoria(cat_id);
            if (respuesta)
            {
                return RedirectToAction("MantenedorCategoria");
            }
            else
            {
                return View("Mantenedores/MantenedorCategoria");
            }
        }



        public async Task<IActionResult> MantenedorLugar()
        {
            List<Lugar> lLugar = await _serviciosApi.ListaLugares();
            return View("Mantenedores/MantenedorLugar", lLugar);
        }

        public IActionResult CrearLugarForm()
        {
            return View("FormularioCrear/CrearLugar");
        }

        public IActionResult ModificarLugarForm(int place_id)
        {
            Lugar place = new Lugar() { place_id = place_id };
            return View("FormularioModificar/ModificarLugar", place);
        }

        public async Task<IActionResult> CrearLugar(Lugar place)
        {
            bool respuesta = await _serviciosApi.CrearLugar(place);
            if (respuesta)
            {
                return RedirectToAction("MantenedorLugar");
            }
            else
            {
                return View("FormularioCrear/CrearLugar", place);
            }
        }

        public async Task<IActionResult> BuscarLugar(int place_id)
        {
            Lugar place = await _serviciosApi.ObtenerLugar(place_id);
            return View("Detalle/DetalleLugar", place);
        }

        public async Task<IActionResult> ModificarLugar(Lugar place)
        {
            bool respuesta = await _serviciosApi.ModificarLugar(place);
            if (respuesta)
            {
                return RedirectToAction("MantenedorLugar");
            }
            else
            {
                return View("FormularioModificar/ModificarLugar", place);
            }
        }

        public async Task<IActionResult> EliminarLugar(int place_id)
        {
            bool respuesta = false;
            respuesta = await _serviciosApi.EliminarLugar(place_id);
            if (respuesta)
            {
                return RedirectToAction("MantenedorLugar");
            }
            else
            {
                return View("Mantenedores/MantenedorLugar");
            }
        }



        public IActionResult Privacy()
        {
            return View();
        }

    }
}
