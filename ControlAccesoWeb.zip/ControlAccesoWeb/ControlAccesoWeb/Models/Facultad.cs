﻿namespace ControlAccesoWeb.Models
{
    public class Facultad
    {
        public int facu_id { get; set; }
        public string? facu_name { get; set; }
    }
}
