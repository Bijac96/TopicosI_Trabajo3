﻿using ControlAcceso.Modelos;
using Newtonsoft.Json;

namespace ControlAccesoWeb.Models
{
    public class RespuestaAPI
    {
        public string mensaje { get; set; }
        [JsonProperty("lUsuarios")]
        public List<Usuario> user_list { get; set; }
        [JsonProperty("lFacultades")]
        public List<Facultad> facu_list { get; set; }
        [JsonProperty("lRoles")]
        public List<Rol> rol_list { get; set; }
        [JsonProperty("lCategorias")]
        public List<Categoria> cat_list { get; set; }
        [JsonProperty("lLugares")]
        public List<Lugar> place_list { get; set; }
        public Usuario user { get; set; }
        public Facultad facultad { get; set; }
        public Rol rol { get; set; }
        public Categoria categoria { get; set; }
        public Lugar place { get; set; }
        public int cantidad { get; set; }
    }
}
