CREATE PROCEDURE [dbo].[Mantenedor_Categoria]
(
	@catId int='',
	@cat_name varchar(50)='',
	@modo char(1)=''
)
AS
BEGIN
	IF @modo='C'
	BEGIN
		INSERT INTO Categoria
		SELECT @catId, @cat_name;
	END

	IF @modo='L'
    BEGIN
		SELECT * FROM Categoria;
    END

    IF @modo='G'
    BEGIN
        SELECT * FROM Categoria WHERE catId=@catId;
    END

    IF @modo='M'
    BEGIN
        UPDATE Categoria SET cat_name=@cat_name WHERE catId=@catId;
    END

    IF @modo='D'
    BEGIN
	    DELETE FROM Categoria WHERE catId=@catId
    END
END