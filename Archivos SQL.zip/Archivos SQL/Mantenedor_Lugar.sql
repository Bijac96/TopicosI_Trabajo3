CREATE PROCEDURE [dbo].[Mantenedor_Lugar]
(
	@place_id int='',
	@place_name varchar(50)='',
	@modo char(1)=''
)
AS
BEGIN
	IF @modo='C'
	BEGIN
		INSERT INTO Lugar
		SELECT @place_id, @place_name;
	END

	IF @modo='L'
    BEGIN
		SELECT * FROM Lugar;
    END

    IF @modo='G'
    BEGIN
        SELECT * FROM Lugar WHERE place_id=@place_id;
    END

    IF @modo='M'
    BEGIN
        UPDATE Lugar SET place_name=@place_name WHERE place_id=@place_id;
    END

    IF @modo='D'
    BEGIN
	    DELETE FROM Lugar WHERE place_id=@place_id;
    END
END