CREATE PROCEDURE [dbo].[Mantenedor_Rol]
(
	@rol_id int='',
	@rol_name varchar(50)='',
	@modo char(1)=''
)
AS
BEGIN
	IF @modo='C'
	BEGIN
		INSERT INTO Rol
		SELECT @rol_id, @rol_name;
	END
	
    IF @modo='L'
    BEGIN
		SELECT * FROM Rol;
    END

    IF @modo='G'
    BEGIN
        SELECT * FROM Rol WHERE rol_id=@rol_id;
    END

    IF @modo='M'
    BEGIN
        UPDATE Rol SET rol_name=@rol_name WHERE rol_id=@rol_id;
    END

    IF @modo='D'
    BEGIN
	    DELETE FROM Rol where rol_id=@rol_id;
    END
END