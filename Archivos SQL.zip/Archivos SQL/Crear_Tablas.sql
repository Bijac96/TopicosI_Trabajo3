CREATE TABLE Usuario(
    usuId varchar(10) PRIMARY KEY,
    usuNombre varchar(50),
    user_rut varchar(20),
    user_phone varchar(20),
    user_email varchar(50),
    user_catId int,
    user_faculty_id int,
    user_university varchar(100),
    user_role_id int,
    creation_date datetime,
    creator_user_id varchar(10),
    start_date datetime,
    end_date datetime,
    user_status varchar(50)
);
GO
CREATE TABLE Facultad(
	facu_id int PRIMARY KEY,
	facu_name varchar(50),
);
GO
CREATE TABLE Categoria(
	catId int PRIMARY KEY,
	cat_name varchar(50),
);
GO
CREATE TABLE Rol(
	rol_id int PRIMARY KEY,
	rol_name varchar(50),
);
GO
CREATE TABLE Lugar(
	place_id int PRIMARY KEY,
	place_name varchar(50),
);