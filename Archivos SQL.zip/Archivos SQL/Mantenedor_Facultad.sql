CREATE PROCEDURE [dbo].[Mantenedor_Facultad]
(
	@facu_id int='',
	@facu_name varchar(50)='',
	@modo char(1)=''
)
AS
BEGIN
	IF @modo='C'
	BEGIN
		INSERT INTO Facultad
		SELECT @facu_id, @facu_name;
	END

	IF @modo='L'
	BEGIN
		SELECT * FROM Facultad;
    END

    IF @modo='G'
    BEGIN
        SELECT * FROM Facultad WHERE facu_id=@facu_id;
    END

    IF @modo='M'
    BEGIN
        UPDATE Facultad SET facu_name=@facu_name WHERE facu_id=@facu_id;
    END

    IF @modo='D'
    BEGIN
	    DELETE FROM Facultad WHERE facu_id=@facu_Id
    END
END