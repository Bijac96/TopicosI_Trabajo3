CREATE PROCEDURE [dbo].[Mantenedor_UsuarioLugar]
(
	@usuId varchar(10)='',
	@place_id int = '',
	@modo char(1)=''
)
AS
BEGIN
	IF @modo='C'
	BEGIN
		INSERT INTO UsuarioLugar
		SELECT @usuId, @place_id;
	END

    IF @modo='D'
    BEGIN
	    DELETE FROM UsuarioLugar 
		WHERE usuId = @usuId AND place_id = @place_id;
    END
END