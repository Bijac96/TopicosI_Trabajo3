CREATE PROCEDURE [dbo].[Mantenedor_Usuario]
(
	@usuId varchar(10)='',
	@usuNombre varchar(50)='',
	@user_rut varchar(20) = '',
	@user_phone varchar(20) = NULL,
	@user_email varchar(50) = NULL,
	@user_catId int = '',
	@user_faculty_id int = '',
	@user_university varchar(100) = '',
	@user_role_id int = '',
	@creation_date datetime = '',
	@creator_user_id varchar(10) = '',
	@start_date datetime = '',
	@end_date datetime = '',
	@user_status varchar(50) = '',
	@modo char(1)=''
)
AS
BEGIN
	IF @modo='C'
	BEGIN
		INSERT INTO Usuario
		SELECT @usuId, @usuNombre, @user_rut, @user_phone, @user_email, @user_catId, 
			@user_faculty_id, @user_university, @user_role_id, @creation_date, 
			@creator_user_id, @start_date, @end_date, @user_status;
	END

	IF @modo='L'
    BEGIN
        SELECT * FROM Usuario
        WHERE
            (@user_faculty_id = '' OR user_faculty_id = @user_faculty_id)
            AND (@user_university = '' OR user_university = @user_university)
            AND (@user_status = '' OR user_status = @user_status)
            AND (@user_catId = '' OR user_catId = @user_catId)
            AND (@user_role_id = '' OR user_role_id = @user_role_id);
    END

    IF @modo='G'
    BEGIN
        SELECT * FROM Usuario WHERE usuId=@usuId
    END

    IF @modo='M'
    BEGIN
        UPDATE Usuario SET 
			usuNombre = @usuNombre, 
			user_rut = @user_rut, 
			user_phone = @user_phone, 
			user_email = @user_email, 
			user_catId = @user_catId, 
			user_faculty_id = @user_faculty_id,
			user_university = user_university, 
			user_role_id = @user_role_id, 
			start_date = @start_date, 
			end_date=@end_date,
			user_status = @user_status 
		WHERE usuId = @usuId
    END

    IF @modo='D'
    BEGIN
	    DELETE FROM Usuario WHERE usuId=@usuId
    END

	IF @modo='N'
	BEGIN
		SELECT COUNT(*) AS cantidad FROM Usuario
		WHERE
		    (@user_faculty_id = '' OR user_faculty_id = @user_faculty_id)
            AND (@user_university = '' OR user_university = @user_university)
            AND (@user_status = '' OR user_status = @user_status)
            AND (@user_catId = '' OR user_catId = @user_catId)
            AND (@user_role_id = '' OR user_role_id = @user_role_id);
	END
END